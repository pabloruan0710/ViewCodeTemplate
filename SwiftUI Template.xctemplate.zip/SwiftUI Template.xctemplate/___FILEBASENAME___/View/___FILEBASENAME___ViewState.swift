//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//
//

public enum ___FILEBASENAMEASIDENTIFIER___: Equatable {
    case hasData(___VARIABLE_featureName___ViewEntity)
    case hasLoading(Bool)
    case isEmpty
}
