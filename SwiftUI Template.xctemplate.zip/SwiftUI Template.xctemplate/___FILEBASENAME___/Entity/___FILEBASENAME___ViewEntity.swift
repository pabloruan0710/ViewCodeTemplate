//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//
//
import Foundation

public struct ___FILEBASENAMEASIDENTIFIER___: Identifiable, Equatable {
    public var id = UUID()
}
